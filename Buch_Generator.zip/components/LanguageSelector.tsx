
import React from 'react';
import { Language } from '../types';

interface LanguageSelectorProps {
  currentLanguage: Language;
  onChange: (language: Language) => void;
  t: (key: string) => string;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({ currentLanguage, onChange, t }) => {
  return (
    <div className="flex items-center space-x-4">
      <span className="text-sm font-medium text-gray-300">{t('language')}:</span>
      <div className="flex space-x-2">
        {(Object.keys(Language) as Array<keyof typeof Language>).map((langKey) => {
          const langValue = Language[langKey];
          return (
            <button
              key={langValue}
              onClick={() => onChange(langValue)}
              className={`px-3 py-1.5 text-sm rounded-md transition-colors ${
                currentLanguage === langValue
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-gray-700 hover:bg-gray-600 text-gray-200'
              }`}
            >
              {t(langValue === Language.EN ? 'english' : 'german')}
            </button>
          );
        })}
      </div>
    </div>
  );
};
    