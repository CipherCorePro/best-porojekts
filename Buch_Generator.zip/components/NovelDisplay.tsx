
import React from 'react';
import { GeneratedChapter } from '../types';
import ReactMarkdown from 'react-markdown';

interface NovelDisplayProps {
  chapters: GeneratedChapter[];
  t: (key: string) => string;
}

export const NovelDisplay: React.FC<NovelDisplayProps> = ({ chapters, t }) => {

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-primary-500">{t('generatedNovel')}</h2>
      </div>

      <div className="prose prose-invert prose-lg max-w-none bg-gray-850 p-6 rounded-lg shadow-inner">
        <h3 className="text-2xl font-semibold text-primary-400 mt-8 border-b border-gray-700 pb-2 mb-4">{t('contents')}</h3>
        {chapters.sort((a,b) => a.chapterNumber - b.chapterNumber).map(chapter => (
          <div key={chapter.chapterNumber} className="mb-8 p-4 bg-gray-700 rounded-md">
            {/* Title is already part of chapter.content as H2 for markdown rendering */}
            <ReactMarkdown>{chapter.content}</ReactMarkdown>
          </div>
        ))}
      </div>
    </div>
  );
};