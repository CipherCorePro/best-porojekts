
import React, { useCallback } from 'react';
import { FullBook } from '../types';
import ReactMarkdown from 'react-markdown';
import { Button } from './Button';
import { ArrowDownTrayIcon } from '@heroicons/react/24/outline';
import jsPDF from 'jspdf';
import { marked } from 'marked';
import JSZip from 'jszip';


interface BookDisplayProps {
  book: FullBook;
  t: (key: string) => string;
}

export const BookDisplay: React.FC<BookDisplayProps> = ({ book, t }) => {

  const getNovelTitle = () => book.config.synopsis_prompt.substring(0, 40) + '...';

  const downloadMarkdownFile = useCallback(() => {
    let markdownContent = `# ${getNovelTitle()}\n\n`;
    if (book.coverImageUrl) {
        markdownContent += `![${t('bookCover')}](${book.coverImageUrl})\n\n`;
    }
    markdownContent += `## ${t('foreword')}\n\n${book.foreword}\n\n`;
    markdownContent += `## ${t('contents')}\n\n`;
    book.tableOfContents.forEach(item => {
        markdownContent += `* ${item.title}\n`;
    });
    markdownContent += '\n';

    book.chapters.forEach(chapter => {
      markdownContent += `${chapter.content}\n\n---\n\n`;
    });

    const blob = new Blob([markdownContent], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'novel.md';
    link.click();
    URL.revokeObjectURL(url);
  }, [book, t]);

  const downloadPdfFile = useCallback(() => {
    const doc = new jsPDF();
    const page_width = doc.internal.pageSize.getWidth();
    const margin = 15;
    const max_width = page_width - margin * 2;

    // Title Page
    if (book.coverImageUrl) {
        doc.addImage(book.coverImageUrl, 'JPEG', 0, 0, 210, 297);
        doc.addPage();
    }
    
    let y = 20;

    // Foreword
    doc.setFontSize(18);
    doc.text(t('foreword'), page_width / 2, y, { align: 'center' });
    y += 15;
    doc.setFontSize(12);
    const forewordLines = doc.splitTextToSize(book.foreword, max_width);
    doc.text(forewordLines, margin, y);
    y += forewordLines.length * 5 + 10;
    
    doc.addPage();
    y = 20;

    // Table of Contents
    doc.setFontSize(18);
    doc.text(t('contents'), page_width/2, y, { align: 'center' });
    y += 15;
    doc.setFontSize(12);
    book.tableOfContents.forEach(item => {
        doc.text(`${item.chapterNumber}. ${item.title}`, margin, y);
        y += 7;
        if(y > 280){
            doc.addPage();
            y = 20;
        }
    });

    // Chapters
    book.chapters.forEach(chapter => {
        doc.addPage();
        y = 20;
        const lines = doc.splitTextToSize(chapter.content.replace(/##/g, '#'), max_width);
        
        lines.forEach((line: string) => {
            if (line.startsWith('# ')) {
                 doc.setFontSize(16);
                 doc.text(line.substring(2), page_width/2, y, { align: 'center' });
                 y += 10;
                 doc.setFontSize(12);
            } else {
                doc.text(line, margin, y);
                y += 5;
            }

            if (y > 280) {
                doc.addPage();
                y = 20;
            }
        });
    });

    doc.save('novel.pdf');
  }, [book, t]);

  const downloadEpubFile = useCallback(async () => {
    const zip = new JSZip();
    const novelTitle = getNovelTitle();
    const author = "Superprompt Generator";
    
    let coverImageBlob: Blob | null = null;
    if (book.coverImageUrl) {
        try {
            coverImageBlob = await (await fetch(book.coverImageUrl)).blob();
        } catch (e) {
            console.error("Failed to fetch cover image for EPUB, continuing without it.", e);
        }
    }

    const mimetype = 'application/epub+zip';
    zip.file('mimetype', mimetype, {compression: 'STORE'});

    const containerXml = `<?xml version="1.0"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>`;
    zip.folder('META-INF')?.file('container.xml', containerXml);
    
    const oebps = zip.folder('OEBPS');
    oebps?.folder('css');
    oebps?.folder('text');
    if (coverImageBlob) {
        oebps?.folder('images');
        oebps?.file('images/cover.jpg', coverImageBlob);
    }
    
    oebps?.file('css/style.css', 'body { font-family: sans-serif; } h1, h2 { text-align: center; }');

    let opfManifest = `
        ${coverImageBlob ? '<item id="cover-image" href="images/cover.jpg" media-type="image/jpeg" properties="cover-image"/>' : ''}
        <item id="css" href="css/style.css" media-type="text/css"/>
        <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
        <item id="foreword" href="text/foreword.xhtml" media-type="application/xhtml+xml"/>`;
    let opfSpine = `<itemref idref="foreword"/>`;
    let navLis = `<li><a href="text/foreword.xhtml">${t('foreword')}</a></li>`;

    const forewordHtml = await marked.parse(book.foreword);
    oebps?.file('text/foreword.xhtml', `<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="${book.config.language}"><head><title>${t('foreword')}</title><link rel="stylesheet" type="text/css" href="../css/style.css"/></head><body><h1>${t('foreword')}</h1>${forewordHtml}</body></html>`);

    for (const chapter of book.chapters) {
        const chapId = `chap${chapter.chapterNumber}`;
        const chapHref = `text/${chapId}.xhtml`;
        opfManifest += `<item id="${chapId}" href="${chapHref}" media-type="application/xhtml+xml"/>`;
        opfSpine += `<itemref idref="${chapId}"/>`;
        navLis += `<li><a href="${chapHref}">${chapter.title}</a></li>`;
        const chapterHtml = await marked.parse(chapter.content);
        oebps?.file(chapHref, `<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="${book.config.language}"><head><title>${chapter.title}</title><link rel="stylesheet" type="text/css" href="../css/style.css"/></head><body>${chapterHtml}</body></html>`);
    }

    const navXhtml = `<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="${book.config.language}"><head><title>${t('contents')}</title></head><body><nav epub:type="toc"><ol>${navLis}</ol></nav></body></html>`;
    oebps?.file('nav.xhtml', navXhtml);

    const contentOpf = `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="book-id" version="3.0" xml:lang="${book.config.language}">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="book-id">urn:uuid:${crypto.randomUUID()}</dc:identifier>
    <dc:title>${novelTitle}</dc:title>
    <dc:creator>${author}</dc:creator>
    <dc:language>${book.config.language}</dc:language>
    <meta property="dcterms:modified">${new Date().toISOString().split('.')[0]+"Z"}</meta>
  </metadata>
  <manifest>${opfManifest}</manifest>
  <spine>${opfSpine}</spine>
</package>`;
    oebps?.file('content.opf', contentOpf);
    
    const content = await zip.generateAsync({type:'blob', mimeType: 'application/epub+zip'});
    const url = URL.createObjectURL(content);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'novel.epub';
    link.click();
    URL.revokeObjectURL(url);
  }, [book, t]);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-primary-500">{t('generatedNovel')}</h2>
        <div className="flex space-x-2">
            <Button onClick={downloadMarkdownFile} icon={ArrowDownTrayIcon} size="sm" variant="secondary">{t('downloadMarkdown')}</Button>
            <Button onClick={downloadPdfFile} icon={ArrowDownTrayIcon} size="sm" variant="secondary">{t('downloadPDF')}</Button>
            <Button onClick={downloadEpubFile} icon={ArrowDownTrayIcon} size="sm" variant="secondary">{t('downloadEPUB')}</Button>
        </div>
      </div>
      
      <div className="bg-gray-850 p-6 rounded-lg shadow-inner">
          {book.coverImageUrl && (
            <>
              <h3 className="text-2xl font-semibold text-primary-400 border-b border-gray-700 pb-2 mb-4">{t('bookCover')}</h3>
              <img src={book.coverImageUrl} alt={t('bookCover')} className="max-w-xs mx-auto rounded-lg shadow-lg mb-8" />
            </>
          )}
          
          <h3 className="text-2xl font-semibold text-primary-400 border-b border-gray-700 pb-2 mb-4">{t('foreword')}</h3>
          <div className="prose prose-invert prose-lg max-w-none mb-8">
            <ReactMarkdown>{book.foreword}</ReactMarkdown>
          </div>

          <h3 className="text-2xl font-semibold text-primary-400 mt-8 border-b border-gray-700 pb-2 mb-4">{t('contents')}</h3>
          <ul className="list-disc list-inside mb-8 prose prose-invert prose-lg">
            {book.tableOfContents.map(item => (
                <li key={item.chapterNumber}><a href={`#chapter-${item.chapterNumber}`} className="text-primary-400 hover:underline">{item.title}</a></li>
            ))}
          </ul>
          
          {book.chapters.sort((a,b) => a.chapterNumber - b.chapterNumber).map(chapter => (
          <div key={chapter.chapterNumber} id={`chapter-${chapter.chapterNumber}`} className="mb-8 p-4 rounded-md prose prose-invert prose-lg max-w-none">
            <ReactMarkdown>{chapter.content}</ReactMarkdown>
          </div>
        ))}
      </div>
    </div>
  );
};
