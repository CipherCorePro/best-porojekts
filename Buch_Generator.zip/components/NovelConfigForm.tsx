
import React, { useState, useEffect } from 'react';
import { NovelConfig, ModelProvider } from '../types';
import { Button } from './Button';
import { CogIcon } from '@heroicons/react/24/outline';
import { GEMINI_TEXT_MODELS } from '../constants';

interface NovelConfigFormProps {
  initialConfig: NovelConfig;
  onSubmit: (config: NovelConfig) => void;
  t: (key: string) => string;
}

export const NovelConfigForm: React.FC<NovelConfigFormProps> = ({ initialConfig, onSubmit, t }) => {
  const [config, setConfig] = useState<NovelConfig>(initialConfig);

  useEffect(() => {
    setConfig(initialConfig);
  }, [initialConfig]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'radio') {
        const newProvider = value as ModelProvider;
        setConfig(prev => ({
            ...prev,
            modelProvider: newProvider,
            // Reset model when provider changes
            model: newProvider === ModelProvider.GEMINI ? GEMINI_TEXT_MODELS[0] : ''
        }));
        return;
    }

    if (name === "character_prompts") {
      setConfig(prev => ({ ...prev, [name]: value.split('\n') }));
    } else if (name === "chapters_count" || name === "maxTokensPerChapter" || name === "minTokensPerChapter") {
      setConfig(prev => ({ ...prev, [name]: parseInt(value, 10) || 0 }));
    } else {
      setConfig(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(config);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 p-4 md:p-6 bg-gray-800 rounded-lg shadow-xl">
      <h2 className="text-2xl font-semibold text-primary-400 mb-6 text-center">{t('configureNovel')}</h2>
      
      {/* Model Provider Selection */}
      <div className="space-y-4 rounded-lg bg-gray-900/50 p-4 border border-gray-700">
        <label className="block text-lg font-medium text-gray-200 mb-2">{t('modelProvider')}</label>
        <div className="flex items-center space-x-6">
            <div className="flex items-center">
                <input type="radio" id="gemini" name="modelProvider" value={ModelProvider.GEMINI} checked={config.modelProvider === ModelProvider.GEMINI} onChange={handleChange} className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-600 bg-gray-700" />
                <label htmlFor="gemini" className="ml-2 block text-sm font-medium text-gray-200">{t('gemini')}</label>
            </div>
             <div className="flex items-center">
                <input type="radio" id="lmstudio" name="modelProvider" value={ModelProvider.LMSTUDIO} checked={config.modelProvider === ModelProvider.LMSTUDIO} onChange={handleChange} className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-600 bg-gray-700" />
                <label htmlFor="lmstudio" className="ml-2 block text-sm font-medium text-gray-200">{t('lmStudio')}</label>
            </div>
        </div>
        
        {config.modelProvider === ModelProvider.GEMINI && (
            <div className="mt-4">
                <label htmlFor="model" className="block text-sm font-medium text-gray-300 mb-1">{t('model')}</label>
                <select name="model" id="model" value={config.model} onChange={handleChange} className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500">
                    {GEMINI_TEXT_MODELS.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
            </div>
        )}

        {config.modelProvider === ModelProvider.LMSTUDIO && (
            <div className="mt-4 space-y-4">
                <div>
                    <label htmlFor="lmStudioUrl" className="block text-sm font-medium text-gray-300 mb-1">{t('lmStudioUrl')}</label>
                    <input type="text" name="lmStudioUrl" id="lmStudioUrl" value={config.lmStudioUrl} onChange={handleChange} className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500" />
                    <p className="text-xs text-gray-400 mt-1">{t('lmStudioInfo')}</p>
                </div>
                 <div>
                    <label htmlFor="model" className="block text-sm font-medium text-gray-300 mb-1">{t('model')}</label>
                    <input type="text" name="model" id="model" value={config.model} onChange={handleChange} placeholder={t('lmStudioModelPlaceholder')} className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500" required/>
                </div>
            </div>
        )}

        {config.modelProvider === ModelProvider.LMSTUDIO && (
            <p className="text-xs text-amber-400 mt-3">{t('imageGenerationLMWarning')}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="genre" className="block text-sm font-medium text-gray-300 mb-1">{t('genre')}</label>
          <input
            type="text"
            name="genre"
            id="genre"
            value={config.genre}
            onChange={handleChange}
            className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
            required
          />
        </div>
        <div>
          <label htmlFor="chapters_count" className="block text-sm font-medium text-gray-300 mb-1">{t('numberOfChapters')}</label>
          <input
            type="number"
            name="chapters_count"
            id="chapters_count"
            value={config.chapters_count}
            onChange={handleChange}
            min="1"
            className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
            required
          />
        </div>
        <div>
          <label htmlFor="minTokensPerChapter" className="block text-sm font-medium text-gray-300 mb-1">{t('minTokensPerChapter')}</label>
          <input
            type="number"
            name="minTokensPerChapter"
            id="minTokensPerChapter"
            value={config.minTokensPerChapter}
            onChange={handleChange}
            min="256"
            max="64000"
            step="128"
            className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
            required
          />
        </div>
        <div>
          <label htmlFor="maxTokensPerChapter" className="block text-sm font-medium text-gray-300 mb-1">{t('maxTokensPerChapter')}</label>
          <input
            type="number"
            name="maxTokensPerChapter"
            id="maxTokensPerChapter"
            value={config.maxTokensPerChapter}
            onChange={handleChange}
            min="256"
            max="64000"
            step="128"
            className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
            required
          />
        </div>
      </div>

      <div>
        <label htmlFor="synopsis_prompt" className="block text-sm font-medium text-gray-300 mb-1">{t('coreIdea')}</label>
        <textarea
          name="synopsis_prompt"
          id="synopsis_prompt"
          rows={4}
          value={config.synopsis_prompt}
          onChange={handleChange}
          className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
          required
        />
      </div>

      <div>
        <label htmlFor="character_prompts" className="block text-sm font-medium text-gray-300 mb-1">{t('characterPrompts')}</label>
        <textarea
          name="character_prompts"
          id="character_prompts"
          rows={4}
          value={config.character_prompts.join('\n')}
          onChange={handleChange}
          className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
        />
      </div>

      <div>
        <label htmlFor="style_guide" className="block text-sm font-medium text-gray-300 mb-1">{t('styleGuide')}</label>
        <textarea
          name="style_guide"
          id="style_guide"
          rows={3}
          value={config.style_guide}
          onChange={handleChange}
          className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
        />
      </div>

      <div>
        <label htmlFor="bookCoverPrompt" className="block text-sm font-medium text-gray-300 mb-1">{t('bookCoverPrompt')}</label>
        <textarea
          name="bookCoverPrompt"
          id="bookCoverPrompt"
          rows={3}
          value={config.bookCoverPrompt || ''}
          onChange={handleChange}
          className="w-full p-2.5 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500"
          disabled={config.modelProvider !== ModelProvider.GEMINI}
        />
      </div>

      <div className="pt-2">
        <Button type="submit" className="w-full" icon={CogIcon}>
          {t('startPlanning')}
        </Button>
      </div>
    </form>
  );
};