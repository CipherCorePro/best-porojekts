
import React from 'react';
import { GeneratedChapter } from '../types';
import { Button } from './Button';
import { SparklesIcon, ChevronLeftIcon } from '@heroicons/react/24/outline';

interface NovelEditorProps {
  chapters: GeneratedChapter[];
  onChapterChange: (chapterNumber: number, newContent: string) => void;
  onFinalize: () => void;
  onBack: () => void;
  t: (key: string) => string;
}

export const NovelEditor: React.FC<NovelEditorProps> = ({ chapters, onChapterChange, onFinalize, onBack, t }) => {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-primary-500 mb-6 text-center">{t('chapterEditor')}</h2>
      
      <div className="space-y-8">
        {chapters.sort((a, b) => a.chapterNumber - b.chapterNumber).map(chapter => (
          <div key={chapter.chapterNumber} className="bg-gray-850 p-4 rounded-lg shadow-lg">
            <label htmlFor={`chapter-editor-${chapter.chapterNumber}`} className="block text-xl font-semibold text-primary-400 mb-3">
              {chapter.title}
            </label>
            <textarea
              id={`chapter-editor-${chapter.chapterNumber}`}
              value={chapter.content}
              onChange={(e) => onChapterChange(chapter.chapterNumber, e.target.value)}
              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-primary-500 focus:border-primary-500 h-96 resize-y font-mono text-sm"
              aria-label={`${t('chapter')} ${chapter.chapterNumber} ${t('contents')}`}
            />
          </div>
        ))}
      </div>

      <div className="mt-8 pt-4 border-t border-gray-700 flex justify-center space-x-4">
        <Button onClick={onBack} variant="secondary" icon={ChevronLeftIcon}>
          {t('previousStep')}
        </Button>
        <Button onClick={onFinalize} icon={SparklesIcon} variant="success">
          {t('createFullBook')}
        </Button>
      </div>
    </div>
  );
};
