
import React from 'react';
import { NovelPlan, CharacterProfile, ChapterOutline } from '../types';
import { UserCircleIcon, ListBulletIcon, DocumentTextIcon, PencilSquareIcon } from '@heroicons/react/24/outline';

interface PlannerDisplayProps {
  novelPlan: NovelPlan;
  t: (key: string) => string;
}

const SectionWrapper: React.FC<{title: string, icon: React.ElementType, children: React.ReactNode}> = ({ title, icon: Icon, children }) => (
    <div className="bg-gray-800 shadow-lg rounded-xl p-6 mb-8">
        <h3 className="text-2xl font-semibold text-primary-400 mb-4 flex items-center">
            <Icon className="h-7 w-7 mr-3 text-primary-500" />
            {title}
        </h3>
        {children}
    </div>
);

const CharacterCard: React.FC<{character: CharacterProfile, t: (key: string) => string}> = ({ character, t}) => (
    <div className="bg-gray-700 p-4 rounded-lg shadow hover:shadow-xl transition-shadow">
        <h4 className="text-xl font-bold text-primary-300 mb-2">{character.name}</h4>
        <p className="text-sm text-gray-300 mb-1"><strong>{t('age')}:</strong> {character.age}</p>
        <p className="text-sm text-gray-300 mb-1"><strong>{t('appearance')}:</strong> {character.appearance}</p>
        <p className="text-sm text-gray-300 mb-1"><strong>{t('personality')}:</strong> {character.personalityTraits}</p>
        <p className="text-sm text-gray-300 mb-1"><strong>{t('motivations')}:</strong> {character.motivations}</p>
        <p className="text-sm text-gray-300 mb-1"><strong>{t('relationships')}:</strong> {character.keyRelationships}</p>
        <p className="text-sm text-gray-300"><strong>{t('arc')}:</strong> {character.arc}</p>
    </div>
);

const ChapterOutlineCard: React.FC<{chapter: ChapterOutline, t: (key: string) => string}> = ({ chapter, t}) => (
     <div className="bg-gray-700 p-4 rounded-lg shadow hover:shadow-xl transition-shadow">
        <h4 className="text-lg font-semibold text-primary-300 mb-1">{t('chapter')} {chapter.chapter_number}</h4>
        <p className="text-sm text-gray-300 whitespace-pre-line">{chapter.summary}</p>
    </div>
);


export const PlannerDisplay: React.FC<PlannerDisplayProps> = ({ novelPlan, t }) => {
  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-primary-500 mb-6 text-center">{t('novelPlan')}</h2>

      <SectionWrapper title={t('expose')} icon={DocumentTextIcon}>
        <p className="text-gray-200 whitespace-pre-line leading-relaxed">{novelPlan.expose}</p>
      </SectionWrapper>
      
      <SectionWrapper title={t('characters')} icon={UserCircleIcon}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {novelPlan.characters.map((char, index) => (
            <CharacterCard key={index} character={char} t={t} />
          ))}
        </div>
      </SectionWrapper>

      <SectionWrapper title={t('chapterStructure')} icon={ListBulletIcon}>
        <div className="space-y-4">
          {novelPlan.chapter_structure.map((chap, index) => (
            <ChapterOutlineCard key={index} chapter={chap} t={t} />
          ))}
        </div>
      </SectionWrapper>
       <SectionWrapper title={t('styleGuide')} icon={PencilSquareIcon}>
         <p className="text-gray-200 whitespace-pre-line leading-relaxed">{novelPlan.style_guide}</p>
      </SectionWrapper>
    </div>
  );
};
