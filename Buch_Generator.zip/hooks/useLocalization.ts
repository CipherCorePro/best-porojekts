
import { useState, useCallback } from 'react';
import { Language, LocalizedUITexts, UITexts } from '../types';

export const useLocalization = (translations: LocalizedUITexts, initialLanguage: Language) => {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(initialLanguage);

  const setLanguage = useCallback((lang: Language) => {
    setCurrentLanguage(lang);
  }, []);

  const t = useCallback((key: string): string => {
    const langTexts = translations[currentLanguage] as UITexts | undefined;
    if (langTexts && langTexts[key]) {
      return langTexts[key];
    }
    // Fallback to English if key not found in current language, or if current language texts are missing
    const fallbackLangTexts = translations[Language.EN] as UITexts | undefined;
    if (fallbackLangTexts && fallbackLangTexts[key]) {
      return fallbackLangTexts[key];
    }
    // Fallback to key itself if not found anywhere (should not happen with proper setup)
    return key;
  }, [currentLanguage, translations]);

  return { t, setLanguage, currentLanguage };
};
    