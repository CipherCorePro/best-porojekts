
import { GoogleGenAI, GenerateContentResponse, GenerateContentParameters } from "@google/genai";
import { NovelConfig, CharacterProfile, ChapterOutline, NovelPlan, Language } from '../types';
import { GEMINI_MODEL_TEXT, GEMINI_MODEL_IMAGE } from '../constants';

const getApiKey = (): string => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY environment variable not set.");
    throw new Error("API_KEY not configured. Please set the API_KEY environment variable.");
  }
  return apiKey;
};

let ai: GoogleGenAI;
try {
    ai = new GoogleGenAI({ apiKey: getApiKey() });
} catch (e) {
    console.error("Failed to initialize GoogleGenAI:", e);
    // Allow app to load, but API calls will fail until API key is correctly set or if there's an init issue.
    // Error will be thrown when trying to use 'ai' if it's undefined.
}


const cleanJsonString = (jsonStr: string): string => {
  let cleaned = jsonStr.trim();
  // Remove markdown fences for JSON
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = cleaned.match(fenceRegex);
  if (match && match[1]) {
    cleaned = match[1].trim();
  }
  return cleaned;
};

const generatePromptExpose = (config: NovelConfig, lang: Language): string => {
  if (lang === Language.DE) {
    return `Basierend auf der folgenden Kernidee und dem Genre, schreibe ein detailliertes Exposé/Synopsis von ca. 500 Wörtern für einen Roman:\n\nGenre: ${config.genre}\nKernidee: ${config.synopsis_prompt}\n\nDas Exposé sollte die Haupthandlungspunkte, wichtige Konflikte und den übergeordneten Handlungsbogen abdecken. Antworte auf Deutsch und gib die Antwort nur als Text aus.`;
  }
  return `Based on the following core idea and genre, write a detailed 500-word expose/synopsis for a novel:\n\nGenre: ${config.genre}\nCore Idea: ${config.synopsis_prompt}\n\nThe expose should cover the main plot points, major conflicts, and the overall arc. Output the response as plain text only.`;
};

export const generateExpose = async (config: NovelConfig, lang: Language): Promise<string> => {
  if (!ai) throw new Error("Gemini AI SDK not initialized. Check API Key.");
  const prompt = generatePromptExpose(config, lang);
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: GEMINI_MODEL_TEXT,
    contents: prompt,
  });
  return response.text;
};

const generatePromptCharacters = (expose: string, characterPrompts: string[], lang: Language): string => {
  const charPromptsString = characterPrompts.map(p => `- ${p}`).join('\n');
  if (lang === Language.DE) {
    return `Basierend auf dem folgenden Roman-Exposé, erstelle detaillierte Charakterprofile für die folgenden Schlüsselcharaktere. Für jeden Charakter, gib Name (falls nicht angegeben, erfinde einen), Alter, Aussehen, Persönlichkeitsmerkmale (als Array von Strings), Motivationen (als Array von Strings), Schlüsselbeziehungen (als Array von Strings) und ihre Entwicklung in der Geschichte an. Formatiere die Ausgabe als JSON-Array von Charakterobjekten. Alle Zeichenfolgenwerte im JSON müssen auf Deutsch sein. Stelle sicher, dass die Ausgabe ein valides JSON-Array von Charakterobjekten ist. Alle Schlüssel und Zeichenfolgenwerte müssen in doppelten Anführungszeichen stehen. Numerische Werte sollten Zahlen sein, Arrays von Strings für Merkmale, Motivationen und Beziehungen.\n\nRoman-Exposé:\n${expose}\n\nZu profilierende Schlüsselcharaktere:\n${charPromptsString}\n\nAusgabeformat: JSON-Array von Objekten, z.B., [{"name": "...", "age": ..., "appearance": "...", "personalityTraits": ["trait1", "trait2"], "motivations": ["motive1"], "keyRelationships": ["rel1"], "arc": "..."}]. Stelle sicher, dass das JSON valide ist und nur das Array enthält.`;
  }
  return `Based on the following novel expose, create detailed character profiles for the following key characters. For each character, include their name (if not specified, invent one), age, appearance, personality traits (as an array of strings), motivations (as an array of strings), key relationships (as an array of strings), and arc in the story. Format the output as a JSON array of character objects. Ensure the output is a valid JSON array of character objects. All keys and string values must be enclosed in double quotes. Numerical values should be numbers, arrays of strings for traits, motivations, and relationships.\n\nNovel Expose:\n${expose}\n\nKey Characters to Profile:\n${charPromptsString}\n\nOutput Format: JSON array of objects, e.g., [{"name": "...", "age": ..., "appearance": "...", "personalityTraits": ["trait1", "trait2"], "motivations": ["motive1"], "keyRelationships": ["rel1"], "arc": "..."}]. Ensure the JSON is valid and contains only the array.`;
};

export const generateCharacterProfiles = async (expose: string, characterPrompts: string[], lang: Language): Promise<CharacterProfile[]> => {
  if (!ai) throw new Error("Gemini AI SDK not initialized. Check API Key.");
  const prompt = generatePromptCharacters(expose, characterPrompts, lang);
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: GEMINI_MODEL_TEXT,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });

  const cleanedJson = cleanJsonString(response.text);
  try {
    const profiles = JSON.parse(cleanedJson);
    if (!Array.isArray(profiles)) {
        console.error("Parsed character profiles is not an array:", profiles);
        throw new Error("Character profiles response is not a valid array.");
    }
    // TODO: Add more robust validation of profile structure against CharacterProfile type
    return profiles.map(profile => ({
      ...profile,
      // Ensure array fields are indeed arrays, default to empty array if not, or keep string if already string
      personalityTraits: Array.isArray(profile.personalityTraits) ? profile.personalityTraits.join(', ') : (typeof profile.personalityTraits === 'string' ? profile.personalityTraits : ''),
      motivations: Array.isArray(profile.motivations) ? profile.motivations.join(', ') : (typeof profile.motivations === 'string' ? profile.motivations : ''),
      keyRelationships: Array.isArray(profile.keyRelationships) ? profile.keyRelationships.join(', ') : (typeof profile.keyRelationships === 'string' ? profile.keyRelationships : ''),
    })) as CharacterProfile[];
  } catch (e) {
    console.error("Failed to parse character profiles JSON:", e, "Raw response:", response.text, "Cleaned:", cleanedJson);
    throw new Error(`Failed to parse character profiles JSON: ${(e as Error).message}`);
  }
};

const generatePromptChapterStructure = (expose: string, characters: CharacterProfile[], numChapters: number, lang: Language): string => {
  const charSummary = characters.map(c => `- ${c.name}: ${(c.description || (c.personalityTraits || '').substring(0,100) || '') + '...'}`).join('\n');
  if (lang === Language.DE) {
    return `Basierend auf dem folgenden Exposé und den Charakteren, erstelle eine Kapitel-für-Kapitel-Gliederung für einen Roman mit ungefähr ${numChapters} Kapiteln. Gib für jedes Kapitel eine kurze Zusammenfassung (100-200 Wörter), die die Hauptereignisse, Charakterentwicklungen und Plotfortschritte in diesem Kapitel beschreibt. Stelle sicher, dass die Gliederung dem im Exposé beschriebenen Handlungsbogen folgt. Formatiere die Ausgabe als JSON-Array von Kapitelobjekten, jedes mit einem 'chapter_number' (Zahl) und 'summary' (Text) Feld. Der 'summary' Text muss auf Deutsch sein. Alle Schlüssel und Zeichenfolgenwerte müssen in doppelten Anführungszeichen stehen.\n\nRoman-Exposé:\n${expose}\n\nSchlüsselcharaktere:\n${charSummary}\n\nAnzahl der Kapitel: ${numChapters}\n\nAusgabeformat: JSON-Array von Objekten, z.B., [{"chapter_number": 1, "summary": "..."}, ...]. Stelle sicher, dass das JSON valide ist und nur das Array enthält.`;
  }
  return `Based on the following expose and characters, create a chapter-by-chapter outline for a novel with approximately ${numChapters} chapters. For each chapter, provide a brief summary (100-200 words) describing the main events, character developments, and plot progression in that chapter. Ensure the outline follows the plot arc described in the expose. Format the output as a JSON array of chapter objects, each with a 'chapter_number' (number) and 'summary' (string) field. All keys and string values must be enclosed in double quotes.\n\nNovel Expose:\n${expose}\n\nKey Characters:\n${charSummary}\n\nNumber of Chapters: ${numChapters}\n\nOutput Format: JSON array of objects, e.g., [{"chapter_number": 1, "summary": "..."}, ...]. Ensure the JSON is valid and contains only the array.`;
};

export const generateChapterStructure = async (expose: string, characters: CharacterProfile[], numChapters: number, lang: Language): Promise<ChapterOutline[]> => {
  if (!ai) throw new Error("Gemini AI SDK not initialized. Check API Key.");
  const prompt = generatePromptChapterStructure(expose, characters, numChapters, lang);
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: GEMINI_MODEL_TEXT,
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });
  const cleanedJson = cleanJsonString(response.text);
  try {
    const structure = JSON.parse(cleanedJson);
     if (!Array.isArray(structure)) {
        console.error("Parsed chapter structure is not an array:", structure);
        throw new Error("Chapter structure response is not a valid array.");
    }
    return structure as ChapterOutline[];
  } catch (e) {
    console.error("Failed to parse chapter structure JSON:", e, "Raw response:", response.text, "Cleaned:", cleanedJson);
    throw new Error(`Failed to parse chapter structure JSON: ${(e as Error).message}`);
  }
};

const generatePromptChapterContent = (chapterNumber: number, chapterSummary: string, novelPlan: NovelPlan, lang: Language, minTokens?: number): string => {
  const charSummary = novelPlan.characters.map(c => `- ${c.name}: ${((c.personalityTraits || '').substring(0,100) || '') + '...'}`).join('\n');
  const minWords = minTokens ? Math.round(minTokens * 0.75) : 0;
  
  const minLengthInstructionDE = minWords > 0 ? `\n\nStelle sicher, dass das Kapitel mindestens ${minWords} Wörter lang ist.` : '';
  const minLengthInstructionEN = minWords > 0 ? `\n\nEnsure the chapter is at least ${minWords} words long.` : '';

  if (lang === Language.DE) {
    return `Schreibe Kapitel ${chapterNumber} eines Romans basierend auf dem folgenden Plan und Stilrichtlinie. Die Ausgabe sollte im Markdown-Format sein.\n\nGesamtes Roman-Exposé:\n${novelPlan.expose}\n\nSchlüsselcharaktere:\n${charSummary}\n\nKapitel ${chapterNumber} Zusammenfassung/Gliederung:\n${chapterSummary}\n\nSchreibstil-Richtlinie:\n${novelPlan.style_guide}\n\nGeneriere den vollständigen Text für Kapitel ${chapterNumber} auf Deutsch in Markdown. Füge eine Markdown-Überschrift für den Kapiteltitel hinzu (z.B. ## Kapitel ${chapterNumber}: Titel des Kapitels).${minLengthInstructionDE}`;
  }
  return `Write Chapter ${chapterNumber} of a novel based on the following plan and style guide. The output should be in Markdown format.\n\nOverall Novel Expose:\n${novelPlan.expose}\n\nKey Characters:\n${charSummary}\n\nChapter ${chapterNumber} Summary/Outline:\n${chapterSummary}\n\nWriting Style Guide:\n${novelPlan.style_guide}\n\nGenerate the full text for Chapter ${chapterNumber} in Markdown. Include a Markdown heading for the chapter title (e.g. ## Chapter ${chapterNumber}: Title of Chapter).${minLengthInstructionEN}`;
};

export const generateChapterContent = async (chapterNumber: number, chapterSummary: string, novelPlan: NovelPlan, lang: Language, maxTokens?: number, minTokens?: number): Promise<string> => {
  if (!ai) throw new Error("Gemini AI SDK not initialized. Check API Key.");
  const prompt = generatePromptChapterContent(chapterNumber, chapterSummary, novelPlan, lang, minTokens);

  const request: GenerateContentParameters = {
    model: GEMINI_MODEL_TEXT,
    contents: prompt,
  };

  if (maxTokens && maxTokens > 0) {
    request.config = {
      maxOutputTokens: maxTokens,
    };
  }

  const response: GenerateContentResponse = await ai.models.generateContent(request);
  return response.text;
};

const generatePromptForeword = (novelPlan: NovelPlan, lang: Language): string => {
    if (lang === Language.DE) {
        return `Schreibe ein fesselndes Vorwort (ca. 250 Wörter) für einen Roman mit dem folgenden Exposé. Das Vorwort sollte den Ton des Romans angeben, das zentrale Thema andeuten, ohne die Handlung zu verraten, und den Leser neugierig machen. Schreibe es auf Deutsch.\n\nExposé:\n${novelPlan.expose}`;
    }
    return `Write a compelling foreword (around 250 words) for a novel with the following exposé. The foreword should set the tone of the novel, hint at the central theme without spoiling the plot, and intrigue the reader. Write it in English.\n\nExposé:\n${novelPlan.expose}`;
};

export const generateForeword = async (novelPlan: NovelPlan, lang: Language): Promise<string> => {
    if (!ai) throw new Error("Gemini AI SDK not initialized. Check API Key.");
    const prompt = generatePromptForeword(novelPlan, lang);
    const response = await ai.models.generateContent({
        model: GEMINI_MODEL_TEXT,
        contents: prompt,
    });
    return response.text;
};

const generatePromptBookCover = (novelPlan: NovelPlan, novelConfig: NovelConfig, lang: Language): string => {
    if (novelConfig.bookCoverPrompt && novelConfig.bookCoverPrompt.trim() !== '') {
        return novelConfig.bookCoverPrompt;
    }

    if (lang === Language.DE) {
        return `Ein Buchcover für einen ${novelConfig.genre}-Roman. Die Geschichte handelt von: ${novelPlan.expose}. Der Stil sollte atmosphärisch und fesselnd sein und die Essenz der Geschichte widerspiegeln. Generiere ein Bild ohne Text.`;
    }
    return `A book cover for a ${novelConfig.genre} novel. The story is about: ${novelPlan.expose}. The style should be atmospheric and captivating, reflecting the essence of the story. Generate an image with no text on it.`;
};

export const generateBookCover = async (novelPlan: NovelPlan, novelConfig: NovelConfig, lang: Language): Promise<string | null> => {
    if (!ai) throw new Error("Gemini AI SDK not initialized. Check API Key.");
    const prompt = generatePromptBookCover(novelPlan, novelConfig, lang);
    try {
        const response = await ai.models.generateImages({
            model: GEMINI_MODEL_IMAGE,
            prompt: prompt,
            config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
        });

        if (!response.generatedImages || response.generatedImages.length === 0) {
            console.warn("Book cover image could not be generated (empty response). Continuing without a cover.");
            return null;
        }
        return response.generatedImages[0].image.imageBytes;
    } catch (error) {
        console.error("Error generating book cover:", error);
        console.warn("Continuing without a book cover due to an API error.");
        return null;
    }
};