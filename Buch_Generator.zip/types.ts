
export enum Language {
  EN = 'en',
  DE = 'de'
}

export interface CharacterProfile {
  name: string;
  age: number | string; // Age can be a number or descriptive string like "Ancient"
  appearance: string;
  personalityTraits: string;
  motivations: string;
  keyRelationships: string;
  arc: string;
  description?: string; // Optional, as used in planner.py char_summary
}

export interface ChapterOutline {
  chapter_number: number;
  summary: string;
}

export interface NovelPlan {
  expose: string;
  characters: CharacterProfile[];
  chapter_structure: ChapterOutline[];
  style_guide: string;
}

export interface NovelConfig {
  genre: string;
  synopsis_prompt: string;
  character_prompts: string[];
  chapters_count: number;
  style_guide: string;
  language: Language;
  maxTokensPerChapter: number;
  minTokensPerChapter: number;
  bookCoverPrompt: string;
}

export interface GeneratedChapter {
  chapterNumber: number;
  title: string; // Extracted or generated
  content: string; // Markdown content
}

export enum AppStage {
  CONFIG = 'CONFIG',
  PLANNING_EXPOSE = 'PLANNING_EXPOSE',
  PLANNING_CHARACTERS = 'PLANNING_CHARACTERS',
  PLANNING_STRUCTURE = 'PLANNING_STRUCTURE',
  VIEW_PLAN = 'VIEW_PLAN',
  WRITING_CHAPTERS = 'WRITING_CHAPTERS',
  VIEW_NOVEL = 'VIEW_NOVEL',
  EDIT_NOVEL = 'EDIT_NOVEL',
  GENERATING_BOOK = 'GENERATING_BOOK',
  VIEW_BOOK = 'VIEW_BOOK'
}

export interface UITexts {
  [key: string]: string;
}

export interface LocalizedUITexts {
  [Language.EN]: UITexts;
  [Language.DE]: UITexts;
}

export interface FullBook {
    coverImageUrl: string | null; // base64 data URL or null if not generated
    foreword: string;
    tableOfContents: { title: string; chapterNumber: number }[];
    chapters: GeneratedChapter[];
    plan: NovelPlan;
    config: NovelConfig;
}