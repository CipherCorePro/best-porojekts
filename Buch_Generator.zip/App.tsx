

import React, { useState, useCallback, useEffect } from 'react';
import { NovelConfig, NovelPlan, GeneratedChapter, Language, AppStage, FullBook } from './types';
import { DEFAULT_NOVEL_CONFIG_EN, DEFAULT_NOVEL_CONFIG_DE, UI_TEXTS } from './constants';
import { NovelConfigForm } from './components/NovelConfigForm';
import { PlannerDisplay } from './components/PlannerDisplay';
import { NovelDisplay } from './components/NovelDisplay';
import { NovelEditor } from './components/NovelEditor';
import { BookDisplay } from './components/BookDisplay';
import { LoadingSpinner } from './components/LoadingSpinner';
import { Button } from './components/Button';
import { LanguageSelector } from './components/LanguageSelector';
import { generateExpose as apiGenerateExpose, generateCharacterProfiles as apiGenerateCharacterProfiles, generateChapterStructure as apiGenerateChapterStructure, generateChapterContent as apiGenerateChapterContent, generateForeword as apiGenerateForeword, generateBookCover as apiGenerateBookCover } from './services/geminiService';
import { useLocalization } from './hooks/useLocalization';
import { BookOpenIcon, CogIcon, PencilSquareIcon, ArrowPathIcon, ChevronLeftIcon, DocumentTextIcon, SparklesIcon, PencilIcon } from '@heroicons/react/24/outline';

const App: React.FC = () => {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(Language.DE);
  const { t, setLanguage } = useLocalization(UI_TEXTS, currentLanguage);

  const [novelConfig, setNovelConfig] = useState<NovelConfig>(DEFAULT_NOVEL_CONFIG_DE);
  const [novelPlan, setNovelPlan] = useState<NovelPlan | null>(null);
  const [generatedChapters, setGeneratedChapters] = useState<GeneratedChapter[]>([]);
  const [fullBook, setFullBook] = useState<FullBook | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [currentStage, setCurrentStage] = useState<AppStage>(AppStage.CONFIG);

  useEffect(() => {
    setLanguage(currentLanguage);
    setNovelConfig(currentLanguage === Language.EN ? DEFAULT_NOVEL_CONFIG_EN : DEFAULT_NOVEL_CONFIG_DE);
  }, [currentLanguage, setLanguage]);

  const handleLanguageChange = (lang: Language) => {
    setCurrentLanguage(lang);
  };

  const handleConfigSubmit = (config: NovelConfig) => {
    setNovelConfig(config);
    setError(null);
    setNovelPlan(null);
    setGeneratedChapters([]);
    setFullBook(null);
    setCurrentStage(AppStage.PLANNING_EXPOSE);
  };
  
  const handleChapterChange = useCallback((chapterNumber: number, newContent: string) => {
    setGeneratedChapters(prevChapters =>
      prevChapters.map(chap =>
        chap.chapterNumber === chapterNumber ? { ...chap, content: newContent } : chap
      )
    );
  }, []);

  const generatePlan = useCallback(async () => {
    if (!novelConfig) return;

    setIsLoading(true);
    setError(null);
    let planInProgress: Partial<NovelPlan> = {};

    try {
      setCurrentStage(AppStage.PLANNING_EXPOSE);
      setLoadingMessage(t('generateExpose'));
      const expose = await apiGenerateExpose(novelConfig, novelConfig.language);
      planInProgress.expose = expose;
      setNovelPlan(prev => ({...prev, ...planInProgress} as NovelPlan));

      setCurrentStage(AppStage.PLANNING_CHARACTERS);
      setLoadingMessage(t('generateCharacters'));
      const characters = await apiGenerateCharacterProfiles(expose, novelConfig.character_prompts, novelConfig.language);
      planInProgress.characters = characters;
      setNovelPlan(prev => ({...prev, ...planInProgress} as NovelPlan));
      
      setCurrentStage(AppStage.PLANNING_STRUCTURE);
      setLoadingMessage(t('generateStructure'));
      const chapter_structure = await apiGenerateChapterStructure(expose, characters, novelConfig.chapters_count, novelConfig.language);
      planInProgress.chapter_structure = chapter_structure;
      planInProgress.style_guide = novelConfig.style_guide;
      
      setNovelPlan(planInProgress as NovelPlan);
      setCurrentStage(AppStage.VIEW_PLAN);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : String(err));
      setCurrentStage(AppStage.CONFIG);
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [novelConfig, t]);

  useEffect(() => {
    if (currentStage === AppStage.PLANNING_EXPOSE && novelConfig) {
      generatePlan();
    }
  }, [currentStage, novelConfig, generatePlan]);


  const writeChapters = useCallback(async () => {
    if (!novelPlan || !novelConfig) return;

    setIsLoading(true);
    setError(null);
    setCurrentStage(AppStage.WRITING_CHAPTERS);
    const newChapters: GeneratedChapter[] = [];

    try {
      for (const chapterOutline of novelPlan.chapter_structure) {
        setLoadingMessage(`${t('writingChapter')} ${chapterOutline.chapter_number}...`);
        const fullNovelPlanForChapter: NovelPlan = {
            expose: novelPlan.expose,
            characters: novelPlan.characters,
            chapter_structure: novelPlan.chapter_structure,
            style_guide: novelPlan.style_guide || novelConfig.style_guide,
        };
        const chapterContent = await apiGenerateChapterContent(
            chapterOutline.chapter_number, 
            chapterOutline.summary, 
            fullNovelPlanForChapter,
            novelConfig.language,
            novelConfig.maxTokensPerChapter,
            novelConfig.minTokensPerChapter
        );
        
        const titleMatch = chapterContent.match(/^(?:##?)\s*(.*)/m);
        const title = titleMatch ? titleMatch[1] : `${t('chapter')} ${chapterOutline.chapter_number}`;

        const newChapter = { 
            chapterNumber: chapterOutline.chapter_number, 
            title: title,
            content: chapterContent 
        };
        newChapters.push(newChapter);
        setGeneratedChapters(prev => [...prev, newChapter]);
      }
      setCurrentStage(AppStage.VIEW_NOVEL);
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setIsLoading(false);
      setLoadingMessage('');
    }
  }, [novelPlan, novelConfig, t]);
  
  const generateBook = useCallback(async () => {
      if (!novelPlan || !novelConfig || generatedChapters.length === 0) return;

      setIsLoading(true);
      setError(null);
      setCurrentStage(AppStage.GENERATING_BOOK);
      setLoadingMessage(t('generatingBook'));

      try {
        const combinedChapterContent = generatedChapters.map(c => c.content).join('\n\n');
        const temporaryPlanForGeneration: NovelPlan = {
          ...novelPlan,
          expose: `${novelPlan.expose}\n\n${combinedChapterContent}` // Use combined content for better context
        }

        const [forewordResult, coverResult] = await Promise.allSettled([
            apiGenerateForeword(temporaryPlanForGeneration, currentLanguage),
            apiGenerateBookCover(temporaryPlanForGeneration, novelConfig, currentLanguage)
        ]);
        
        if (forewordResult.status === 'rejected') {
            // If foreword fails, we consider it a critical error and stop.
            throw forewordResult.reason;
        }
        const foreword = forewordResult.value;

        let coverImageBase64 = null;
        if (coverResult.status === 'fulfilled') {
            coverImageBase64 = coverResult.value;
        } else {
            // Log the error but continue, as the cover is not critical.
            console.error("Book cover generation failed, but continuing without it:", coverResult.reason);
        }

        const tableOfContents = generatedChapters
            .sort((a,b) => a.chapterNumber - b.chapterNumber)
            .map(c => ({ title: c.title, chapterNumber: c.chapterNumber }));

        setFullBook({
            coverImageUrl: coverImageBase64 ? `data:image/jpeg;base64,${coverImageBase64}` : null,
            foreword,
            tableOfContents,
            chapters: generatedChapters,
            plan: novelPlan,
            config: novelConfig,
        });

        setCurrentStage(AppStage.VIEW_BOOK);

      } catch (err) {
        console.error("A critical error occurred during book generation (e.g., foreword failed):", err);
        setError(err instanceof Error ? err.message : String(err));
        setCurrentStage(AppStage.EDIT_NOVEL); // Go back to editor on error
      } finally {
          setIsLoading(false);
          setLoadingMessage('');
      }

  }, [novelPlan, novelConfig, generatedChapters, currentLanguage, t]);


  const resetApp = () => {
    if (window.confirm(t('confirmReset'))) {
        setCurrentLanguage(Language.DE);
        setNovelConfig(DEFAULT_NOVEL_CONFIG_DE);
        setNovelPlan(null);
        setGeneratedChapters([]);
        setFullBook(null);
        setError(null);
        setIsLoading(false);
        setLoadingMessage('');
        setCurrentStage(AppStage.CONFIG);
    }
  };
  
    const stageOrder = [AppStage.CONFIG, AppStage.VIEW_PLAN, AppStage.VIEW_NOVEL, AppStage.EDIT_NOVEL, AppStage.VIEW_BOOK];
  
    const getStageIndex = (stage: AppStage): number => {
        if ([AppStage.PLANNING_EXPOSE, AppStage.PLANNING_CHARACTERS, AppStage.PLANNING_STRUCTURE, AppStage.VIEW_PLAN].includes(stage)) return stageOrder.indexOf(AppStage.VIEW_PLAN);
        if ([AppStage.WRITING_CHAPTERS, AppStage.VIEW_NOVEL].includes(stage)) return stageOrder.indexOf(AppStage.VIEW_NOVEL);
        if (stage === AppStage.EDIT_NOVEL) return stageOrder.indexOf(AppStage.EDIT_NOVEL);
        if ([AppStage.GENERATING_BOOK, AppStage.VIEW_BOOK].includes(stage)) return stageOrder.indexOf(AppStage.VIEW_BOOK);
        if (stage === AppStage.CONFIG) return stageOrder.indexOf(AppStage.CONFIG);
        return -1; // Should not happen
    }

    const isStageDone = (stage: AppStage) => {
        const currentOrderIndex = getStageIndex(currentStage);
        const targetOrderIndex = stageOrder.indexOf(stage);
        return targetOrderIndex !== -1 && currentOrderIndex > targetOrderIndex;
    }

  const renderStageContent = () => {
    if (isLoading && ![AppStage.WRITING_CHAPTERS, AppStage.GENERATING_BOOK].includes(currentStage)) {
      return <LoadingSpinner message={loadingMessage} />;
    }

    switch (currentStage) {
      case AppStage.CONFIG:
        return <NovelConfigForm initialConfig={novelConfig} onSubmit={handleConfigSubmit} t={t} />;
      case AppStage.PLANNING_EXPOSE:
      case AppStage.PLANNING_CHARACTERS:
      case AppStage.PLANNING_STRUCTURE:
        return <LoadingSpinner message={loadingMessage} />;
      case AppStage.VIEW_PLAN:
        return novelPlan ? (
          <>
            <PlannerDisplay novelPlan={novelPlan} t={t} />
            <div className="mt-8 flex justify-center space-x-4">
                <Button onClick={() => setCurrentStage(AppStage.CONFIG)} variant="secondary" icon={ChevronLeftIcon}>
                    {t('previousStep')}
                </Button>
                <Button onClick={writeChapters} icon={PencilSquareIcon}>
                    {t('startWriting')}
                </Button>
            </div>
          </>
        ) : <p>{t('noContentYet')}</p>;
      case AppStage.WRITING_CHAPTERS:
         return (
          <>
            <LoadingSpinner message={loadingMessage} />
            {generatedChapters.length > 0 && (
                <div className="mt-4">
                    <h3 className="text-xl font-semibold mb-2 text-center">{t('generatedChapters')}</h3>
                    <div className="max-h-60 overflow-y-auto space-y-2 p-2 bg-gray-900 rounded-lg">
                      {generatedChapters.map(ch => (
                          <div key={ch.chapterNumber} className="p-3 bg-gray-800 rounded-lg">
                            <h4 className="text-md font-medium text-primary-400">{ch.title}</h4>
                          </div>
                      ))}
                    </div>
                </div>
            )}
          </>
        );
      case AppStage.VIEW_NOVEL:
        return novelPlan && generatedChapters.length > 0 ? (
          <>
            <NovelDisplay chapters={generatedChapters} t={t} />
             <div className="mt-8 flex justify-center space-x-4">
                <Button onClick={() => setCurrentStage(AppStage.VIEW_PLAN)} variant="secondary" icon={ChevronLeftIcon}>
                    {t('previousStep')}
                </Button>
                <Button onClick={() => setCurrentStage(AppStage.EDIT_NOVEL)} icon={PencilIcon} variant="primary">
                    {t('editAndFinalize')}
                </Button>
            </div>
          </>
        ) : <p>{t('noContentYet')}</p>;
       case AppStage.EDIT_NOVEL:
         return (
            <NovelEditor
              chapters={generatedChapters}
              onChapterChange={handleChapterChange}
              onFinalize={generateBook}
              onBack={() => setCurrentStage(AppStage.VIEW_NOVEL)}
              t={t}
            />
         );
       case AppStage.GENERATING_BOOK:
        return <LoadingSpinner message={loadingMessage} />;
       case AppStage.VIEW_BOOK:
        return fullBook ? (
            <>
                <BookDisplay book={fullBook} t={t}/>
                <div className="mt-8 flex justify-center space-x-4">
                    <Button onClick={() => setCurrentStage(AppStage.EDIT_NOVEL)} variant="secondary" icon={ChevronLeftIcon}>
                        {t('previousStep')}
                    </Button>
                </div>
            </>
        ) : <p>{t('noContentYet')}</p>;
      default:
        return <p>Unknown stage.</p>;
    }
  };

  const StageIndicator: React.FC<{icon: React.ElementType, title: string, active: boolean, done: boolean}> = ({icon: Icon, title, active, done}) => (
    <div className={`flex flex-col items-center p-2 md:p-4 rounded-lg transition-all duration-300 w-1/5 md:w-auto ${active ? 'bg-primary-700 scale-105' : done ? 'bg-green-700' : 'bg-gray-700 hover:bg-gray-600'}`}>
        <Icon className={`h-6 w-6 md:h-8 md:w-8 mb-1 ${active || done ? 'text-white' : 'text-primary-400'}`} />
        <span className="text-xs md:text-sm text-center font-medium">{title}</span>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4">
      <header className="w-full max-w-6xl mb-6 text-center">
        <div className="flex justify-between items-center mb-4">
            <LanguageSelector currentLanguage={currentLanguage} onChange={handleLanguageChange} t={t} />
            <Button onClick={resetApp} variant="danger" size="sm" icon={ArrowPathIcon}>
                {t('reset')}
            </Button>
        </div>
        <h1 className="text-4xl font-bold text-primary-500 flex items-center justify-center">
            <BookOpenIcon className="h-10 w-10 mr-3"/>
            {t('appName')}
        </h1>
      </header>

      <main className="w-full max-w-6xl bg-gray-800 shadow-2xl rounded-lg p-6 md:p-8">
        <div className="flex justify-around mb-6 md:mb-8 border-b border-gray-700 pb-4">
            <StageIndicator icon={CogIcon} title={t('configureNovel')} active={currentStage === AppStage.CONFIG} done={isStageDone(AppStage.CONFIG)} />
            <StageIndicator icon={DocumentTextIcon} title={t('generatePlan')} active={[AppStage.PLANNING_EXPOSE, AppStage.PLANNING_CHARACTERS, AppStage.PLANNING_STRUCTURE, AppStage.VIEW_PLAN].includes(currentStage)} done={isStageDone(AppStage.VIEW_PLAN)} />
            <StageIndicator icon={PencilSquareIcon} title={t('generateChapters')} active={[AppStage.WRITING_CHAPTERS, AppStage.VIEW_NOVEL].includes(currentStage)} done={isStageDone(AppStage.VIEW_NOVEL)} />
            <StageIndicator icon={PencilIcon} title={t('editNovel')} active={currentStage === AppStage.EDIT_NOVEL} done={isStageDone(AppStage.EDIT_NOVEL)} />
            <StageIndicator icon={SparklesIcon} title={t('createBook')} active={[AppStage.GENERATING_BOOK, AppStage.VIEW_BOOK].includes(currentStage)} done={isStageDone(AppStage.VIEW_BOOK)} />
        </div>
        
        {error && (
          <div className="mb-4 p-4 bg-red-800 border border-red-600 text-red-100 rounded-lg">
            <p className="font-semibold">{t('errorOccurred')}:</p>
            <p className="text-sm">{error}</p>
            <Button onClick={() => { setError(null); setCurrentStage(AppStage.CONFIG); }} variant="secondary" size="sm" className="mt-2">{t('reset')}</Button>
          </div>
        )}
        {renderStageContent()}
      </main>
      <footer className="w-full max-w-6xl mt-8 text-center text-sm text-gray-500">
        <p>&copy; {new Date().getFullYear()} Book Generator. Powered by Gemini. Developed by Ralf Krümmel CipherCore Technologie</p>
      </footer>
    </div>
  );
};

export default App;